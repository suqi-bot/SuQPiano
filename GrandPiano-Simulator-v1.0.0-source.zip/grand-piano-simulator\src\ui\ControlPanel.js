/**
 * ControlPanel — DOM 控制面板与状态栏绑定
 * 面板结构写在 index.html 中，这里只负责事件绑定与刷新。
 */

import { DEMO_SONGS } from '../app/DemoSongs.js';
import { midiToName, isBlackKey } from '../core/NoteUtils.js';
import { NoteWaterfall } from './NoteWaterfall.js';

const $ = (id) => document.getElementById(id);

export class ControlPanel {
  constructor(app) {
    this.app = app;
    this.values = { volume: 0.75, velocity: 0.85, reverb: 0.32 };
    this._lastStatus = {};
    this.waterfall = new NoteWaterfall($('wf-stream'));
    this._build();
  }

  _build() {
    const app = this.app;

    // ---- 示范曲下拉 ----
    const selDemo = $('sel-demo');
    if (selDemo) {
      selDemo.innerHTML = DEMO_SONGS
        .map((s) => `<option value="${s.id}">${s.name}</option>`).join('');
    }

    // ---- 音量 ----
    this._slider('volume', (v) => {
      this.values.volume = v;
      if (app.audioReady) app.synth.setMasterVolume(v);
      this._text('volume-val', Math.round(v * 100) + '%');
    });

    // ---- 触键力度 ----
    this._slider('velocity', (v) => {
      this.values.velocity = v;
      app.setVelocityScale(v);
      this._text('velocity-val', Math.round(v * 100) + '%');
    });

    // ---- 混响 ----
    this._slider('reverb', (v) => {
      this.values.reverb = v;
      if (app.audioReady) app.synth.setReverb(v);
      this._text('reverb-val', Math.round(v * 100) + '%');
    });

    // ---- 延音踏板 ----
    const pedal = $('btn-pedal');
    pedal?.addEventListener('pointerdown', (e) => { e.preventDefault(); app.setPedal(true); });
    window.addEventListener('pointerup', () => app.setPedal(false));
    pedal?.addEventListener('click', (e) => e.preventDefault());

    // ---- 标签模式 ----
    $('sel-label')?.addEventListener('change', (e) => app.setLabelMode(e.target.value));

    // ---- 视角 ----
    $('sel-view')?.addEventListener('change', (e) => app.setView(e.target.value));

    // ---- 琴盖 ----
    $('btn-lid')?.addEventListener('click', () => app.toggleLid());

    // ---- 示范曲播放 / 停止 ----
    $('btn-demo-play')?.addEventListener('click', async () => {
      await app.ensureAudio();
      app.playDemo(selDemo?.value || DEMO_SONGS[0].id);
    });
    $('btn-demo-stop')?.addEventListener('click', () => app.stopDemo());

    // ---- 录制 / 循环回放 ----
    $('btn-rec')?.addEventListener('click', () => app.recorder.toggleRecord());
    $('btn-rec-play')?.addEventListener('click', async () => {
      await app.ensureAudio();
      app.recorder.play(true);
    });
    $('btn-rec-stop')?.addEventListener('click', () => app.recorder.stopPlay());
    $('btn-rec-clear')?.addEventListener('click', () => app.recorder.clear());

    // ---- 音符编辑器 ----
    $('btn-note-editor')?.addEventListener('click', async () => {
      if (!app.recorder.editableNotes().length) {
        // 无内容也允许进入，便于双击空白新建
      }
      await app.ensureAudio().catch(() => {});
      app.noteEditor.open();
    });

    // ---- 八度平移按钮 ----
    $('btn-oct-down')?.addEventListener('click', () => app.input._shiftOctave(-1));
    $('btn-oct-up')?.addEventListener('click', () => app.input._shiftOctave(1));

    // ---- 音名流清空 ----
    $('btn-wf-clear')?.addEventListener('click', () => this.waterfall?.clear());

    // ---- 初始化文本 ----
    ['volume', 'velocity', 'reverb'].forEach((k) => {
      const el = $(k);
      if (el) { el.value = String(this.values[k]); el.dispatchEvent(new Event('input')); }
    });
  }

  _slider(id, cb) {
    const el = $(id);
    if (!el) return;
    const handler = () => cb(parseFloat(el.value));
    el.addEventListener('input', handler);
    handler();
  }

  _text(id, txt) { const el = $(id); if (el) el.textContent = txt; }

  setPedalState(on) {
    const el = $('btn-pedal');
    if (el) el.classList.toggle('is-active', on);
    this._text('pedal-state', on ? '踩下' : '松开');
  }

  setLidState(open) {
    const el = $('btn-lid');
    if (el) { el.textContent = open ? '关闭琴盖' : '打开琴盖'; el.classList.toggle('is-active', open); }
  }

  setViewName(name) {
    const el = $('sel-view');
    if (el && el.value !== name) el.value = name;
  }

  setDemoPlaying(playing) {
    const p = $('btn-demo-play'), s = $('btn-demo-stop');
    p?.classList.toggle('is-active', playing);
    if (p) p.textContent = playing ? '播放中…' : '播放';
    if (s) s.disabled = !playing;
  }

  /** 录制 / 回放状态联动（Recorder 调用） */
  setRecorderState(state) {
    if (state.recording !== undefined) {
      const b = $('btn-rec');
      if (b) { b.textContent = state.recording ? '■ 停止录制' : '● 录制'; b.classList.toggle('is-active', state.recording); }
    }
    if (state.playing !== undefined) {
      const p = $('btn-rec-play'), s = $('btn-rec-stop');
      p?.classList.toggle('is-active', state.playing);
      if (p) p.textContent = state.playing ? '循环中…' : '循环播放';
      if (s) s.disabled = !state.playing;
    }
    if (state.count !== undefined) this._text('rec-status', `${state.count} 个`);
  }

  onNoteOn(midi, vel) {
    this._text('stat-note', midiToName(midi) + '  (' + midi + ')');
    const bar = $('stat-vel-bar');
    if (bar) bar.style.width = Math.round(vel * 100) + '%';
    this.waterfall?.push(midiToName(midi), vel, isBlackKey(midi));
  }

  updateStatus(info) {
    if (info.note) this._text('stat-note', `${info.note.name}  (${info.note.midi})`);
    if (info.octaveBase !== undefined) {
      this._text('stat-octave', `${midiToName(info.octaveBase)} ~ ${midiToName(info.octaveBase + 33)}`);
    }
    if (info.voices !== undefined) this._text('stat-voices', String(info.voices));
    if (info.fps !== undefined) this._text('stat-fps', String(info.fps));
    if (info.latency !== undefined) this._text('stat-latency', info.latency.toFixed(1) + ' ms');
  }
}
