/**
 * PianoModel — 三角钢琴（Grand Piano）参数化建模
 *
 * 关键设计：
 *   · 坐标：+X 右手(高音) / +Y 上 / +Z 演奏者方向；原点位于地面投影中心；
 *     FLOOR_Y = -0.50 → 键面 WHITE_TOP = 0.22，键面距地 72cm（人体工学）。
 *   · 琴身轮廓用 C¹ 连续的闭合 CatmullRom 曲线（直线前沿 + 平滑尾/弧），
 *     解决旧版 bezier/quadratic 衔接处切线不连续导致 offsetPolygon 产生
 *     尖刺、铸铁框整板异常外扩 0.15m 的 bug。
 *   · 多边形内缩用基于"两条偏移边求交" + 斜接限幅 + 倒角回退的稳健算法，
 *     锐角处不再失控。
 *   · 琴键改为"绕平衡销转动"（pivot 位于键面下方、距前沿 2/3 处），
 *     与真实三角钢琴一致；前端下沉 10mm，后端微微抬起（被 fallboard 遮挡）。
 *   · 击弦机：槌头 + 槌柄（单刚体绕 hammer rail 旋转，按键抬起槌头击弦）；
 *     制音器头 + 制音杆（绕后枢转动）。
 *   · 琴弦：低音段采用 over-stringing 交叉排布（前端往高音侧偏移，
 *     尾端落在低音侧 hitch pin 板），与真琴一致。
 *   · 踏板琴架：两根立柱 + 横梁从键托底面直连踏板箱（消除旧版 22cm 悬空），
 *     三块踏板绕后枢转动，前端下踩，并加三根黄铜连杆向上连接击弦机。
 *   · 顶盖：加长铰链筒 + 铰链螺丝；铸铁框加板面固定螺栓；颊木加螺丝。
 *   · 顶盖最大开度 0.69rad(≈40°)，使顶盖顶端不突破高度约束。
 *
 * 对外接口（不变）：
 *   buildPiano(opts) → { group, keys, keyMeshes, bounds, layout,
 *                         materials: M, setDamper, setPedal, updateLid,
 *                         update, lidProgress }
 *   · keys.get(midi) → { midi, isBlack, pivot, mesh, material, length,
 *                        backZ, frontZ, centerX, topY, pivotY, pivotZ,
 *                        press, target, maxAngle }
 *     新增 pivotY / pivotZ（附加字段，旧字段全部保留）
 *   · materials 对象的所有键保持不变；新增字段以"_"前缀命名，不影响绑定。
 */

import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { computeKeyLayout, midiToFreq } from '../core/NoteUtils.js';

// ============================ 尺寸常量 ============================
const FLOOR_Y = -0.50;
const RIM_H = 0.44;
const RIM_WALL = 0.05;
const INNER_RIM_TOP = 0.35;
const WHITE_TOP = 0.22;
const KEY_H = 0.022;
const BLACK_RISE = 0.0115;
const BLACK_H = 0.034;
const KEY_DIP = 0.010;
const SB_Y = 0.26;            // 音板：装在中层内衬上。与琴弦的间距 = 弦桥高度
const PLATE_Y = 0.361;        // 铸铁框：底面正好落在内框顶面(0.35)上，不再悬空
const STRING_Y = 0.395;
const BALANCE_RAIL_Z = 0.049;          // 平衡销统一高度，键围绕其转动

// ============================ 几何工具 ============================

/** 缩放 BoxGeometry 的"上半"顶点：用于黑键的梯形截面 / 缩顶 */
function taperedBoxGeometry(w, h, l, topScaleX, topScaleZ) {
  const g = new THREE.BoxGeometry(w, h, l);
  const pos = g.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    if (pos.getY(i) > 0) {
      pos.setX(i, pos.getX(i) * topScaleX);
      pos.setZ(i, pos.getZ(i) * topScaleZ);
    }
  }
  pos.needsUpdate = true;
  g.computeVertexNormals();
  return g;
}

/**
 * 稳健的多边形内/外偏移。
 *  - 两条相邻偏移边求交得到正确的斜接点（替代旧版"取相邻外法线均值"的
 *    归一化法，该法在近 180° 顶点处分母趋零、方向失稳，产生尖刺）；
 *  - 斜接长度超限时回退到夹角平分线方向并限幅；
 *  - 平行边（≈ 180° 平顶点）退化为均值法；
 *  - 偏移后逐点约束：剔除 NaN/∞，确保结果闭合、面积同号。
 */
function offsetPolygon(pts, d, miterLimit = 2.0) {
  // ⓪ 去掉相邻重合点：Shape.getPoints() 会在首尾接缝处返回重合点，形成零长边；
  //    零长边的法向退化成 (0,0)，令求交结果飞出，产生数厘米的尖刺（外轮廓鼓包）。
  const src = [];
  for (const p of pts) {
    const q = src[src.length - 1];
    if (q && Math.abs(q.x - p.x) < 1e-9 && Math.abs(q.y - p.y) < 1e-9) continue;
    src.push(p.clone());
  }
  while (src.length > 1) {
    const a = src[0], b = src[src.length - 1];
    if (Math.abs(a.x - b.x) < 1e-9 && Math.abs(a.y - b.y) < 1e-9) src.pop();
    else break;
  }
  const n = src.length;
  if (n < 3) return src;

  let area = 0;
  for (let i = 0; i < n; i++) {
    const p = src[i], q = src[(i + 1) % n];
    area += p.x * q.y - q.x * p.y;
  }
  const ccw = area > 0;
  const s = ccw ? 1 : -1;                       // CCW 时 +1 → 边缘外法向 = (dy,-dx)

  // 源包围盒：内缩 |d| 后结果必然落在源包围盒向内收 |d| 的范围内（近凸轮廓严格成立）。
  // 超出即为斜接超限 / 退化边造成的尖刺，直接钳回去，保证偏移结果绝不外扩。
  let bx0 = Infinity, by0 = Infinity, bx1 = -Infinity, by1 = -Infinity;
  for (const p of src) {
    if (p.x < bx0) bx0 = p.x;
    if (p.x > bx1) bx1 = p.x;
    if (p.y < by0) by0 = p.y;
    if (p.y > by1) by1 = p.y;
  }
  const r = Math.abs(d) * 0.98;
  const cx0 = bx0 + r, cx1 = bx1 - r, cy0 = by0 + r, cy1 = by1 - r;

  const out = [];
  for (let i = 0; i < n; i++) {
    const a = src[(i - 1 + n) % n], p = src[i], b = src[(i + 1) % n];

    const dx1 = p.x - a.x, dy1 = p.y - a.y;
    const dx2 = b.x - p.x, dy2 = b.y - p.y;
    const l1 = Math.hypot(dx1, dy1) || 1;
    const l2 = Math.hypot(dx2, dy2) || 1;

    // 两条边的外法向
    const n1x = s * dy1 / l1, n1y = s * (-dx1) / l1;
    const n2x = s * dy2 / l2, n2y = s * (-dx2) / l2;

    // 偏移后边 1：过 (a + n1*d) 方向沿 (dx1,dy1)
    const A1x = a.x + n1x * d, A1y = a.y + n1y * d;
    const u1x = dx1 / l1, u1y = dy1 / l1;
    // 偏移后边 2：过 (p + n2*d) 方向沿 (dx2,dy2)
    const A2x = p.x + n2x * d, A2y = p.y + n2y * d;
    const u2x = dx2 / l2, u2y = dy2 / l2;

    // 求交：(A1 + t*u1) = (A2 + s*u2) → 2D 标量叉积
    const crossUV = u1x * u2y - u1y * u2x;
    let ix, iy;
    if (Math.abs(crossUV) < 1e-9) {
      // 平行（≈ 180° 平顶点）→ 用均值法
      const mx = n1x + n2x, my = n1y + n2y;
      const ml = Math.hypot(mx, my) || 1;
      ix = p.x + (mx / ml) * d;
      iy = p.y + (my / ml) * d;
    } else {
      const wx = A2x - A1x, wy = A2y - A1y;
      const t = (wx * u2y - wy * u2x) / crossUV;
      ix = A1x + t * u1x;
      iy = A1y + t * u1y;
    }

    // 斜接长度限幅
    const miterLen = Math.hypot(ix - p.x, iy - p.y) / Math.max(1e-6, Math.abs(d));
    if (miterLen > miterLimit) {
      const bx = n1x + n2x, by = n1y + n2y;
      const bl = Math.hypot(bx, by) || 1;
      ix = p.x + (bx / bl) * d * miterLimit;
      iy = p.y + (by / bl) * d * miterLimit;
    }
    if (!Number.isFinite(ix) || !Number.isFinite(iy)) { ix = p.x; iy = p.y; }
    // ⓪ 安全钳制：内缩结果不得超出源包围盒内收 |d| 的范围 → 彻底杜绝尖刺外扩
    if (d < 0) {
      if (cx1 > cx0) ix = Math.min(Math.max(ix, cx0), cx1);
      if (cy1 > cy0) iy = Math.min(Math.max(iy, cy0), cy1);
    }
    out.push(new THREE.Vector2(ix, iy));
  }
  return out;
}

/** 把 (x, depth) 平面的 Shape 挤出成厚度沿 +Y 的板，depth 轴映射到 -Z */
function extrudeUp(shape, thickness, curveSegments = 48) {
  const geo = new THREE.ExtrudeGeometry(shape, {
    depth: thickness, bevelEnabled: false, curveSegments, steps: 1,
  });
  geo.rotateX(-Math.PI / 2);
  return geo;
}

/**
 * 三角钢琴翼形轮廓（x: 左右，d: 0=琴身前沿(键盘侧) → D=琴尾）
 *  - 前沿为直线（保持钢琴前缘平直），用 C¹ 闭合 CatmRom 曲线连接弧形侧板
 *    与圆尾（消除旧版 bezier/quadratic 衔接处的切线不连续，避免偏移尖刺）；
 *  - 高音侧（x1 一侧）外鼓后收束到琴尾；低音侧（x0 一侧）为接近直线的脊。
 *
 * 控制点（绝对坐标，已按目标宽度/深度设计）：
 *   前沿宽度 = x1 - x0 ≈ 1.224m；最大外鼓 ≈ +0.072；尾端最大 d ≈ 0.99·D。
 *   整体宽 ≤ 1.30m、深 ≈ D（落在自检 1.1~1.35 / 1.2~1.7 区间）。
 */
function buildBodyShape(x0, x1, D) {
  const W = x1 - x0;
  const shape = new THREE.Shape();
  shape.moveTo(x0, 0);
  shape.lineTo(x1, 0);

  // 弧形侧板 + 尾 + 直线脊 的控制点（11 点；A0 = (x1,0) 与 A10 = (x0,0)
  // 与前沿首尾相接；前后两个角为 90° 圆角，偏移时斜接 ≈ √2，无尖刺）
  // d 乘数控制在 0..1.02 内，确保尾部落在 ≈ D（避免旧版 Bezier "略超 D"
  // 模式在 CatmRom 上被放大成 1.47×D 把尾部推到 2.2m 的 bug）。
  const Wref = W;
  const C = [
    [x1, 0.00 * D],                          // A0  前沿-高音角
    [x1 + 0.038, 0.12 * D],                  // A1  起鼓
    [x1 + 0.060, 0.42 * D],                  // A2  最大外鼓
    [x1 + 0.040, 0.68 * D],                  // A3  收束
    [x1 - 0.070, 0.90 * D],                  // A4  近尾
    [x0 + Wref * 0.78, 1.00 * D],            // A5  尾-高音
    [x0 + Wref * 0.30, 1.02 * D],            // A6  尾-低音（微超出以做圆尾）
    [x0 + 0.045, 0.96 * D],                  // A7  尾后
    [x0 - 0.008, 0.65 * D],                  // A8  脊
    [x0 - 0.008, 0.30 * D],                  // A9  脊
    [x0, 0.00 * D],                          // A10 前沿-低音角
  ];
  // CatmullRom 闭区间 false，从 C[0] 到 C[10]
  const v3 = C.map(([x, y]) => new THREE.Vector3(x, y, 0));
  const curve = new THREE.CatmullRomCurve3(v3, false, 'centripetal', 0.5);
  const samples = curve.getPoints(160);     // 160+1 段 → 极密，C¹ 连续
  for (let i = 1; i < samples.length; i++) {
    shape.lineTo(samples[i].x, samples[i].y);
  }
  shape.closePath();
  return shape;
}

/** 在两点之间放置一根圆柱（用于连杆/支撑杆） */
function orientCylinder(mesh, a, b) {
  const dir = new THREE.Vector3().subVectors(b, a);
  const len = dir.length();
  mesh.position.copy(a).addScaledVector(dir, 0.5);
  mesh.scale.set(1, len, 1);
  mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.normalize());
}

function lerp(a, b, t) { return a + (b - a) * t; }

// ============================ 程序化纹理 ============================

/**
 * 在浏览器外（Node 自检）返回 null，让建模逻辑可在无 DOM 环境下完整跑通，
 * 浏览器行为不受影响（map: null 退化为纯色）。
 */
function createCanvas(w, h) {
  if (typeof document === 'undefined') return null;
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  return c;
}

/** 云杉木纹（音板） */
function woodGrainTexture() {
  const c = createCanvas(256, 256);
  if (!c) return null;
  const g = c.getContext('2d');
  g.fillStyle = '#dcb87f';
  g.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 46; i++) {
    const y = Math.random() * 256;
    g.strokeStyle = `rgba(${140 + Math.random() * 30 | 0},${92 + Math.random() * 20 | 0},42,${0.07 + Math.random() * 0.12})`;
    g.lineWidth = 1 + Math.random() * 2.2;
    g.beginPath();
    g.moveTo(0, y);
    let yy = y;
    for (let x = 0; x <= 256; x += 32) { yy += (Math.random() - 0.5) * 7; g.lineTo(x, yy); }
    g.stroke();
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.anisotropy = 4;
  return tex;
}

/** 金色铭牌文字（黄铜底 + 暗刻 GRAND） */
function nameBoardTexture() {
  const c = createCanvas(1024, 128);
  if (!c) return null;
  const g = c.getContext('2d');
  const grad = g.createLinearGradient(0, 0, 0, 128);
  grad.addColorStop(0, '#dcbd6e');
  grad.addColorStop(0.5, '#c9a24e');
  grad.addColorStop(1, '#b38e3d');
  g.fillStyle = grad;
  g.fillRect(0, 0, 1024, 128);
  g.strokeStyle = 'rgba(60,40,10,0.55)'; g.lineWidth = 6;
  g.strokeRect(30, 14, 964, 100);
  g.strokeStyle = 'rgba(255,235,180,0.55)'; g.lineWidth = 2;
  g.strokeRect(38, 22, 948, 84);
  g.textAlign = 'center'; g.textBaseline = 'middle';
  g.font = '600 58px Georgia, "Times New Roman", "Songti SC", serif';
  g.fillStyle = 'rgba(52,34,8,0.85)';
  g.fillText('GRAND', 512, 68);
  g.fillStyle = 'rgba(255,240,200,0.35)';
  g.fillText('GRAND', 510, 66);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return tex;
}

// ============================ 材质 ============================

function createMaterials() {
  const wood = woodGrainTexture();
  return {
    ebony: new THREE.MeshPhysicalMaterial({          // 高光乌木漆面（外壳/顶盖/颊木）
      color: 0x0c0c0e, roughness: 0.07, metalness: 0.05,
      clearcoat: 1, clearcoatRoughness: 0.045, envMapIntensity: 1.55,
    }),
    ebonySat: new THREE.MeshPhysicalMaterial({       // 亚光乌木（底板/内舱）
      color: 0x141416, roughness: 0.55, metalness: 0.0,
      clearcoat: 0.25, clearcoatRoughness: 0.4,
    }),
    innerRim: new THREE.MeshPhysicalMaterial({       // 内框（音板周圈）
      color: 0x1d1d20, roughness: 0.32, metalness: 0.0,
      clearcoat: 0.5, clearcoatRoughness: 0.2,
    }),
    soundboard: new THREE.MeshPhysicalMaterial({     // 云杉音板
      map: wood || null, color: 0xf5e9cf, roughness: 0.58, metalness: 0.0,
      clearcoat: 0.3, clearcoatRoughness: 0.5, envMapIntensity: 0.9,
    }),
    plate: new THREE.MeshStandardMaterial({          // 铸铁框（亮金）
      color: 0xd8b25c, roughness: 0.34, metalness: 0.75, envMapIntensity: 2.1,
      emissive: 0x4a2c00, emissiveIntensity: 0.38,
    }),
    steel: new THREE.MeshStandardMaterial({          // 钢弦
      color: 0xeee9de, roughness: 0.20, metalness: 1.0, envMapIntensity: 1.9,
      emissive: 0x202020, emissiveIntensity: 0.10,
    }),
    copper: new THREE.MeshStandardMaterial({         // 铜缠弦
      color: 0xc98a48, roughness: 0.30, metalness: 1.0, envMapIntensity: 1.9,
      emissive: 0x2a1600, emissiveIntensity: 0.22,
    }),
    felt: new THREE.MeshStandardMaterial({ color: 0x8c2025, roughness: 0.98, metalness: 0.0 }),
    feltDark: new THREE.MeshStandardMaterial({ color: 0x5a1417, roughness: 1.0, metalness: 0.0 }),
    feltWhite: new THREE.MeshStandardMaterial({ color: 0xf0ede3, roughness: 0.95, metalness: 0.0 }),
    brass: new THREE.MeshStandardMaterial({ color: 0xcfa752, roughness: 0.24, metalness: 1.0 }),
    whiteKey: new THREE.MeshPhysicalMaterial({
      color: 0xf6f3ec, roughness: 0.28, metalness: 0.0,
      clearcoat: 0.55, clearcoatRoughness: 0.12, envMapIntensity: 0.85,
    }),
    blackKey: new THREE.MeshPhysicalMaterial({
      color: 0x101014, roughness: 0.12, metalness: 0.0,
      clearcoat: 1, clearcoatRoughness: 0.05, envMapIntensity: 1.3,
    }),
    leather: new THREE.MeshPhysicalMaterial({ color: 0x232328, roughness: 0.6, clearcoat: 0.2 }),
    // 附加材质（"_" 前缀，避免误绑到原有逻辑）
    _seam: new THREE.MeshStandardMaterial({ color: 0x050507, roughness: 0.8, metalness: 0.0 }),
    _screw: new THREE.MeshStandardMaterial({ color: 0x2a2a2e, roughness: 0.45, metalness: 0.6 }),
    _hinge: new THREE.MeshStandardMaterial({ color: 0x9a8240, roughness: 0.35, metalness: 0.85 }),
  };
}

// ============================ 主构建函数 ============================

export function buildPiano({ startMidi = 28, endMidi = 108 } = {}) {
  const M = createMaterials();
  const root = new THREE.Group();

  const layout = computeKeyLayout(startMidi, endMidi);
  const KW = layout.totalWidth;                 // 键盘宽度 = 1.128m
  const PAD = 0.048;                            // 颊木余量（已从 0.05 微调）
  const x0 = -PAD, x1 = KW + PAD;
  const DEPTH = 1.48;                            // 琴身纵深 1.48m（已修正：旧版 1.60m 过深）
  const cx = KW / 2;

  // ---------------------------------------------------------------
  // 1. 琴身外壳（环形壳体，前缘在 z=0，键盘向前探出）
  // ---------------------------------------------------------------
  const outerShape = buildBodyShape(x0, x1, DEPTH);
  const outerPts = outerShape.getPoints(72);
  const innerPts = offsetPolygon(outerPts, -RIM_WALL);
  const innerPath = new THREE.Path();
  innerPath.setFromPoints([...innerPts].reverse());
  outerShape.holes.push(innerPath);

  const rim = new THREE.Mesh(extrudeUp(outerShape, RIM_H, 96), M.ebony);
  rim.castShadow = true; rim.receiveShadow = true;
  root.add(rim);

  // 底板
  const bottomShape = buildBodyShape(x0, x1, DEPTH);
  const bottom = new THREE.Mesh(extrudeUp(bottomShape, 0.018, 64), M.ebonySat);
  bottom.position.y = -0.018;
  bottom.receiveShadow = true;
  root.add(bottom);

  // 外壳分缝：内框周圈的暗色嵌条（让分块可读）
  addShellSeams(root, M, innerPts, DEPTH);

  // ---------------------------------------------------------------
  // 2. 内框 + 音板 + 肋木 + 弦桥
  // ---------------------------------------------------------------
  const innerPts2 = offsetPolygon(innerPts, -0.03);
  const innerShape = new THREE.Shape(innerPts);
  const innerShape2 = new THREE.Shape(innerPts2);
  const innerRingPath = new THREE.Path();
  innerRingPath.setFromPoints([...innerPts2].reverse());
  innerShape.holes.push(innerRingPath);
  const innerRimWall = new THREE.Mesh(extrudeUp(innerShape, INNER_RIM_TOP - SB_Y, 72), M.innerRim);
  innerRimWall.position.y = SB_Y;
  innerRimWall.castShadow = true;
  innerRimWall.receiveShadow = true;
  root.add(innerRimWall);

  const soundboard = new THREE.Mesh(extrudeUp(innerShape2, 0.008, 64), M.soundboard);
  soundboard.position.y = SB_Y - 0.002;
  soundboard.receiveShadow = true;
  root.add(soundboard);

  // 弦桥：真琴的桥必须从音板一路顶到琴弦——弦压在桥上，振动才能传给音板。
  // 旧版桥只有 1.6cm 高，琴弦等于悬在音板上方 28cm 的空中，内腔看着是空的。
  // 做成上窄下宽的斜肩木桥，横向长度收在铸铁框开孔之内，避免穿透框边。
  const BRIDGE_BASE = SB_Y + 0.008;
  const BRIDGE_TOP = STRING_Y - 0.005;
  const bridgeH = Math.max(0.05, BRIDGE_TOP - BRIDGE_BASE);
  const bridge1 = new THREE.Mesh(taperedBoxGeometry(KW * 0.80, bridgeH, 0.028, 1, 0.7), M.soundboard);
  bridge1.position.set(cx, BRIDGE_BASE + bridgeH / 2, -DEPTH * 0.30);
  bridge1.castShadow = true;
  root.add(bridge1);
  const bridge2 = new THREE.Mesh(taperedBoxGeometry(KW * 0.54, bridgeH, 0.026, 1, 0.7), M.soundboard);
  bridge2.position.set(cx - KW * 0.12, BRIDGE_BASE + bridgeH / 2, -DEPTH * 0.58);
  bridge2.castShadow = true;
  root.add(bridge2);

  // 肋木
  const ribGeo = new THREE.BoxGeometry(1, 0.009, 0.016);
  const ribs = new THREE.InstancedMesh(ribGeo, M.soundboard, 9);
  const m4 = new THREE.Matrix4();
  for (let i = 0; i < 9; i++) {
    const d = DEPTH * (0.24 + i * 0.075);
    const w = KW * (0.92 - Math.pow(Math.max(0, d / DEPTH - 0.55) / 0.45, 2) * 0.55);
    m4.makeScale(w, 1, 1);
    m4.setPosition(cx, SB_Y - 0.012, -d);
    ribs.setMatrixAt(i, m4);
  }
  ribs.instanceMatrix.needsUpdate = true;
  root.add(ribs);

  // ---------------------------------------------------------------
  // 3. 铸铁框：金色整板 + 纵横梁 + 弦枕 + 板面固定螺栓
  // ---------------------------------------------------------------
  const plateGroup = new THREE.Group();
  const plateOutline = offsetPolygon(innerPts2, -0.045);
  const plateShape = new THREE.Shape(plateOutline);
  // 铸铁框做成"周圈边框 + 纵横梁"的镂空结构（真琴如此）。旧版是一整块实心
  // 金板，把音板 / 肋木 / 弦桥 / 琴弦底面全部盖死，内腔看上去是个黑箱。
  const plateInner = offsetPolygon(plateOutline, -0.055);
  const plateHole = new THREE.Path();
  plateHole.setFromPoints([...plateInner].reverse());
  plateShape.holes.push(plateHole);
  // 击弦机"锤线"开口：在前框留一道通缝，让槌头在全行程内穿过前框
  // （真实铸铁框在此留缝，否则槌头顶到弦面时必与前框穿插）。
  const hammerLine = new THREE.Path();
  hammerLine.setFromPoints([
    new THREE.Vector2(x0 + 0.02, -0.110),
    new THREE.Vector2(x1 - 0.02, -0.110),
    new THREE.Vector2(x1 - 0.02, -0.160),
    new THREE.Vector2(x0 + 0.02, -0.160),
  ]);
  plateShape.holes.push(hammerLine);
  const platePanel = new THREE.Mesh(extrudeUp(plateShape, 0.022, 80), M.plate);
  platePanel.position.y = PLATE_Y - 0.011;
  platePanel.castShadow = true;
  plateGroup.add(platePanel);

  // 纵向梁：五条斜向支撑。在弦桥穿过处断开（真琴的铸铁框在此处开拱门），
  // 避免梁与桥互相穿插。
  const frontZ = -0.10, backZ = -DEPTH * 0.92;
  const bridgeGaps = [
    [-DEPTH * 0.30 - 0.022, -DEPTH * 0.30 + 0.022],
    [-DEPTH * 0.58 - 0.021, -DEPTH * 0.58 + 0.021],
  ];
  const barSegs = [];
  let zc = frontZ;
  for (const [g0, g1] of bridgeGaps) {
    if (g0 > zc) barSegs.push([zc, g0]);
    zc = Math.max(zc, g1);
  }
  if (zc < backZ) barSegs.push([zc, backZ]);

  for (let i = 0; i < 5; i++) {
    const t = i / 4;
    const sx = lerp(x0 + 0.10, x1 - 0.10, t);
    const ex = lerp(x0 + 0.18, x1 - 0.30, t);
    for (const [z0, z1] of barSegs) {
      const ta = (z0 - frontZ) / (backZ - frontZ);
      const tb = (z1 - frontZ) / (backZ - frontZ);
      const xa = lerp(sx, ex, ta), xb = lerp(sx, ex, tb);
      const len = Math.abs(z1 - z0);
      if (len < 0.02) continue;
      const bar = new THREE.Mesh(new THREE.BoxGeometry(0.030, 0.020, len), M.plate);
      bar.position.set((xa + xb) / 2, PLATE_Y + 0.008, (z0 + z1) / 2);
      bar.rotation.y = Math.atan2(xb - xa, z1 - z0);
      bar.castShadow = true;
      plateGroup.add(bar);
    }
  }
  // 横向梁
  for (const [z, w] of [[-0.26, KW * 0.94], [-DEPTH * 0.62, KW * 0.78], [-DEPTH * 0.90, KW * 0.46]]) {
    const bar = new THREE.Mesh(new THREE.BoxGeometry(w, 0.018, 0.026), M.plate);
    bar.position.set(cx, PLATE_Y + 0.008, z);
    bar.castShadow = true;
    plateGroup.add(bar);
  }
  // 弦枕（前）+ 后压弦条
  // 前弦枕（agraffe）被用户感知为键盘后方一条突兀的亮黄色横条，
  // 且与 fallboard 高度差不协调。先移除这个装饰条，琴弦仍由弦钉锚定。
  // const agraffe = new THREE.Mesh(new THREE.BoxGeometry(KW * 0.94, 0.028, 0.030), M.plate);
  // agraffe.position.set(cx, PLATE_Y + 0.014, -0.11);
  // agraffe.castShadow = true;
  // plateGroup.add(agraffe);
  const backCapo = new THREE.Mesh(new THREE.BoxGeometry(KW * 0.78, 0.020, 0.020), M.plate);
  backCapo.position.set(cx - KW * 0.06, PLATE_Y + 0.010, -DEPTH * 0.78);
  plateGroup.add(backCapo);
  // 挂弦钉板（低音侧）
  const hitch = new THREE.Mesh(new THREE.BoxGeometry(0.044, 0.026, DEPTH * 0.62), M.plate);
  hitch.position.set(x0 + 0.10, PLATE_Y + 0.010, -DEPTH * 0.40);
  hitch.rotation.y = 0.03;
  plateGroup.add(hitch);
  // 板面固定螺栓（10 颗，分布在纵横梁交叉点和板周边）
  const screwGeo = new THREE.CylinderGeometry(0.008, 0.008, 0.012, 10);
  const screws = new THREE.InstancedMesh(screwGeo, M._screw, 10);
  const screwPos = [
    [x0 + 0.16, -0.24], [x1 - 0.18, -0.24],
    [x0 + 0.20, -DEPTH * 0.50], [x1 - 0.24, -DEPTH * 0.50],
    [x0 + 0.28, -DEPTH * 0.80], [x1 - 0.30, -DEPTH * 0.80],
    [cx, -0.24], [cx, -DEPTH * 0.50], [cx, -DEPTH * 0.78], [cx - KW * 0.22, -DEPTH * 0.78],
  ];
  const mq = new THREE.Matrix4().makeRotationX(Math.PI / 2);
  screwPos.forEach(([sx, sz], i) => {
    m4.makeTranslation(sx, PLATE_Y + 0.024, sz).multiply(mq);
    screws.setMatrixAt(i, m4);
  });
  screws.instanceMatrix.needsUpdate = true;
  plateGroup.add(screws);
  root.add(plateGroup);

  // 内腔补光
  const interiorLight = new THREE.PointLight(0xffe8c8, 20, 3.6, 1.7);
  interiorLight.position.set(cx, 0.42, -DEPTH * 0.5);
  root.add(interiorLight);

  // ---------------------------------------------------------------
  // 4. 琴弦：低音 over-stringing + 调律钉 + 挂弦钉
  // ---------------------------------------------------------------
  const stringDefs = [];
  for (const k of layout.keys) {
    const f = midiToFreq(k.midi);
    const t = (k.midi - startMidi) / Math.max(1, endMidi - startMidi);
    const isLow = k.midi < 52;                          // 低音段
    const copper = k.midi < 52;
    const count = k.midi < 36 ? 2 : (k.midi < 60 ? 2 : 3);
    const len = Math.min(DEPTH * 0.92, Math.max(0.30, 1.22 * Math.pow(440 / f, 0.42)));
    const radius = Math.max(0.0016, Math.min(0.0048, 0.0048 * Math.pow(440 / f, 0.33)));
    for (let u = 0; u < count; u++) {
      const off = (u - (count - 1) / 2) * 0.0050;
      // 低音交叉排布：调律钉往高音侧偏移、挂弦钉落在低音侧 hitch 板附近
      const x1 = 0.055 + t * (KW - 0.11) + off
        + (isLow ? (52 - k.midi) * 0.0042 : 0);
      const x2 = isLow
        ? x0 + 0.12 + (1 - t) * KW * 0.18 + off * 0.4
        : x1 + off * 0.1;
      stringDefs.push({
        copper, radius,
        x1, z1: -0.07,
        x2, z2: -0.07 - len,
      });
    }
  }
  const cylGeo = new THREE.CylinderGeometry(1, 1, 1, 6, 1, true);
  const copperCount = stringDefs.filter((s) => s.copper).length;
  const steelCount = stringDefs.length - copperCount;
  const copperMesh = new THREE.InstancedMesh(cylGeo, M.copper, copperCount);
  const steelMesh = new THREE.InstancedMesh(cylGeo, M.steel, steelCount);
  const q = new THREE.Quaternion();
  const up = new THREE.Vector3(0, 1, 0);
  const pa = new THREE.Vector3(), pb = new THREE.Vector3(), dir = new THREE.Vector3();
  const sc = new THREE.Vector3();
  let ci = 0, si = 0;
  for (const s of stringDefs) {
    pa.set(s.x1, STRING_Y, s.z1);
    pb.set(s.x2, STRING_Y, s.z2);
    dir.subVectors(pb, pa);
    const len = dir.length();
    q.setFromUnitVectors(up, dir.clone().normalize());
    sc.set(s.radius, len, s.radius);
    m4.compose(pa.clone().addScaledVector(dir, 0.5), q, sc);
    if (s.copper) copperMesh.setMatrixAt(ci++, m4);
    else steelMesh.setMatrixAt(si++, m4);
  }
  copperMesh.instanceMatrix.needsUpdate = true;
  steelMesh.instanceMatrix.needsUpdate = true;
  root.add(copperMesh, steelMesh);

  // 调律钉（前端，板面）
  const tuningPinGeo = new THREE.CylinderGeometry(0.0020, 0.0022, 0.026, 6);
  const tuningPins = new THREE.InstancedMesh(tuningPinGeo, M.brass, stringDefs.length);
  stringDefs.forEach((s, i) => {
    m4.makeTranslation(s.x1, PLATE_Y + 0.020, s.z1);
    tuningPins.setMatrixAt(i, m4);
  });
  tuningPins.instanceMatrix.needsUpdate = true;
  root.add(tuningPins);

  // 挂弦钉（尾端，板面）
  const hitchPinGeo = new THREE.CylinderGeometry(0.0019, 0.0021, 0.022, 6);
  const hitchPins = new THREE.InstancedMesh(hitchPinGeo, M.brass, stringDefs.length);
  stringDefs.forEach((s, i) => {
    m4.makeTranslation(s.x2, PLATE_Y + 0.018, s.z2);
    hitchPins.setMatrixAt(i, m4);
  });
  hitchPins.instanceMatrix.needsUpdate = true;
  root.add(hitchPins);

  // ---------------------------------------------------------------
  // 5. 击弦机：槌头+槌柄（单刚体，按键抬起）+ 制音器头+制音杆
  // ---------------------------------------------------------------
  // 击弦机几何：静止时槌头落在弦面下方 ~5cm、靠击弦机一侧（z<agraffe），
  // 击弦时绕 rail 旋转到竖直、槌头顶正好贴到弦面 (STRING_Y)。
  // 之前 SHANK_LEN=0.080 太短、rail 太低，槌头顶到 y=0.351 就停，离弦 44mm。
  const HAMMER_RAIL_Y = 0.290;                 // rail 升高到弦面附近（击弦时毡头顶略入弦面）
  const HAMMER_RAIL_Z = -0.085;                // 略靠后，使静止槌头落在 agraffe 之后
  const SHANK_LEN = 0.105;                     // 真实三角钢琴槌柄约 9~10.5cm
  const hammerRest = { y: 0.342, z: -0.174 };  // 静止：弦面下 5cm、agraffe 之后
  const hammerHit = { y: 0.391, z: -0.085 };   // 击弦：槌头顶触弦面 (0.391+0.0035≈0.395)
  const hammerGroup = new THREE.Group();
  const shankGeo = new THREE.CylinderGeometry(0.0019, 0.0024, SHANK_LEN, 6);
  shankGeo.translate(0, SHANK_LEN / 2, 0);
  const headGeo = new THREE.BoxGeometry(0.010, 0.007, 0.015);
  headGeo.translate(0, SHANK_LEN, 0);
  const hammerGeo = mergeTwo(shankGeo, headGeo);
  hammerGeo.computeVertexNormals();
  const hammers = new THREE.InstancedMesh(hammerGeo, M.feltWhite, layout.keys.length);
  const hammerDefs = [];
  // 静止时把局部 +Y 旋转到 (rest - rail) 方向 → 绕 +X 的转角 = atan2(dz, dy)
  const restAngle = Math.atan2(hammerRest.z - HAMMER_RAIL_Z, hammerRest.y - HAMMER_RAIL_Y);
  const hitAngle = Math.atan2(hammerHit.z - HAMMER_RAIL_Z, hammerHit.y - HAMMER_RAIL_Y);
  const MAX_HAMMER_ANGLE = hitAngle - restAngle;       // 按键正向旋转使头抬起击弦
  for (let i = 0; i < layout.keys.length; i++) {
    hammerDefs.push({ centerX: layout.keys[i].centerX });
  }
  const _hQ = new THREE.Quaternion();
  const _hAxis = new THREE.Vector3(1, 0, 0);
  const _hPos = new THREE.Vector3();
  const _hScale = new THREE.Vector3(1, 1, 1);
  function refreshHammers(pressArr) {
    for (let i = 0; i < hammerDefs.length; i++) {
      const p = pressArr[i] || 0;
      _hQ.setFromAxisAngle(_hAxis, restAngle + p * MAX_HAMMER_ANGLE);
      _hPos.set(hammerDefs[i].centerX, HAMMER_RAIL_Y, HAMMER_RAIL_Z);
      m4.compose(_hPos, _hQ, _hScale);
      hammers.setMatrixAt(i, m4);
    }
    hammers.instanceMatrix.needsUpdate = true;
  }
  refreshHammers(layout.keys.map(() => 0));
  hammers.castShadow = true;
  hammerGroup.add(hammers);
  // 击弦机舱
  const actionBay = new THREE.Mesh(new THREE.BoxGeometry(KW * 0.96, 0.10, 0.22), M.ebonySat);
  actionBay.position.set(cx, 0.20, -0.18);
  actionBay.castShadow = true;
  hammerGroup.add(actionBay);
  // 槌柄横梁
  const hammerRail = new THREE.Mesh(new THREE.BoxGeometry(KW * 0.96, 0.012, 0.026), M.ebonySat);
  hammerRail.position.set(cx, HAMMER_RAIL_Y - 0.005, HAMMER_RAIL_Z);
  hammerGroup.add(hammerRail);
  root.add(hammerGroup);

  // ---------------------------------------------------------------
  // 6. 制音器：制音头（felt）+ 制音杆（绕后枢转动）
  // ---------------------------------------------------------------
  const DAMPER_PIVOT_Y = 0.205;
  const DAMPER_PIVOT_Z = -0.030;
  const DAMPER_HEAD_REST_Y = STRING_Y - 0.011;        // 静止时头顶正好贴弦（顶 y=STRING_Y）
  const DAMPER_HEAD_REST_Z = -0.115;
  const DAMPER_HEAD_LIFT = 0.017;
  const damperHeadGeo = new THREE.BoxGeometry(0.012, 0.022, 0.030);   // 几何中心在原点
  const dampers = new THREE.InstancedMesh(damperHeadGeo, M.feltDark, layout.keys.length);
  const damperLeverGeo = new THREE.CylinderGeometry(0.0017, 0.0017, 1, 6);   // 单位长，实例缩放
  const damperLevers = new THREE.InstancedMesh(damperLeverGeo, M.ebonySat, layout.keys.length);
  const damperDefs = [];
  for (let i = 0; i < layout.keys.length; i++) {
    const kk = layout.keys[i];
    const t = (kk.midi - startMidi) / Math.max(1, endMidi - startMidi);
    const x = 0.055 + t * (KW - 0.11);
    damperDefs.push({ x, lifted: false, midi: kk.midi });
  }
  const damperIndex = new Map();
  const _dPa = new THREE.Vector3();
  const _dPb = new THREE.Vector3();
  const _dDir = new THREE.Vector3();
  const _dQuat = new THREE.Quaternion();
  const _dUp = new THREE.Vector3(0, 1, 0);
  const _dPos = new THREE.Vector3();
  const _dScale = new THREE.Vector3();
  function refreshDampers() {
    for (let i = 0; i < damperDefs.length; i++) {
      const d = damperDefs[i];
      const headY = DAMPER_HEAD_REST_Y + (d.lifted ? DAMPER_HEAD_LIFT : 0);
      const headZ = DAMPER_HEAD_REST_Z;
      m4.makeTranslation(d.x, headY, headZ);
      dampers.setMatrixAt(i, m4);
      // 杆：后枢 → 头底
      _dPa.set(d.x, DAMPER_PIVOT_Y, DAMPER_PIVOT_Z);
      _dPb.set(d.x, headY - 0.011, headZ);
      _dDir.subVectors(_dPb, _dPa);
      const len = _dDir.length();
      _dQuat.setFromUnitVectors(_dUp, _dDir.clone().normalize());
      _dPos.copy(_dPa).addScaledVector(_dDir, 0.5);
      _dScale.set(1, len, 1);
      m4.compose(_dPos, _dQuat, _dScale);
      damperLevers.setMatrixAt(i, m4);
    }
    dampers.instanceMatrix.needsUpdate = true;
    damperLevers.instanceMatrix.needsUpdate = true;
  }
  damperDefs.forEach((d, i) => { damperIndex.set(d.midi, i); });
  refreshDampers();
  dampers.castShadow = true;
  root.add(dampers, damperLevers);

  // ---------------------------------------------------------------
  // 7. 键盘区域：键托 + 键前踢脚板 + 键后挡板 + 颊木 + 谱架
  // ---------------------------------------------------------------
  const keyBed = new THREE.Mesh(new THREE.BoxGeometry(KW + PAD * 2, 0.022, 0.18), M.ebonySat);
  keyBed.position.set(cx, 0.187, 0.055);
  keyBed.receiveShadow = true; keyBed.castShadow = true;
  root.add(keyBed);

  // 正面踢脚板（低矮前板，让琴键露出）
  const keySlip = new THREE.Mesh(new THREE.BoxGeometry(KW + PAD * 2, 0.045, 0.016), M.ebony);
  keySlip.position.set(cx, 0.178, 0.158);
  keySlip.castShadow = true;
  root.add(keySlip);

  // 键前红呢条 + 后档呢
  const feltFront = new THREE.Mesh(new THREE.BoxGeometry(KW, 0.005, 0.006), M.felt);
  feltFront.position.set(cx, 0.196, 0.148);
  root.add(feltFront);
  const feltBack = new THREE.Mesh(new THREE.BoxGeometry(KW, 0.005, 0.004), M.felt);
  feltBack.position.set(cx, 0.196, -0.005);
  root.add(feltBack);

  // 颊木（键盘两侧）
  for (const sx of [x0 + PAD / 2, x1 - PAD / 2]) {
    const cheek = new THREE.Mesh(new THREE.BoxGeometry(PAD, 0.11, 0.17), M.ebony);
    cheek.position.set(sx, 0.235, 0.055);
    cheek.castShadow = true;
    root.add(cheek);
    // 颊木螺丝（2 颗）
    for (const cz of [0.02, 0.10]) {
      const s = new THREE.Mesh(new THREE.CylinderGeometry(0.0035, 0.0035, 0.004, 8), M._screw);
      s.position.set(sx, 0.240, cz);
      s.rotation.x = Math.PI / 2;
      root.add(s);
    }
  }

  // 键后挡板（fallboard 顶板 + 前板）
  // 加高 3cm，使顶面（0.370）遮住铸铁框顶（0.372），消除键盘后方露出的金条。
  const fallboard = new THREE.Mesh(new THREE.BoxGeometry(KW, 0.19, 0.020), M.ebony);
  fallboard.position.set(cx, 0.275, -0.02);
  fallboard.castShadow = true;
  root.add(fallboard);

  // 金色铭牌
  const nameTex = nameBoardTexture();
  const namePlane = new THREE.Mesh(
    new THREE.PlaneGeometry(KW * 0.72, 0.085),
    new THREE.MeshBasicMaterial({ map: nameTex || null }),
  );
  namePlane.position.set(cx, 0.277, -0.005);
  root.add(namePlane);

  // 谱架（带中央支撑）
  // 整体抬高 3cm，避免与加高的 fallboard 穿插；中央支撑柱改短并上移，
  // 从 fallboard 顶（≈0.37）连到谱架面板底（≈0.40）。
  const desk = new THREE.Group();
  const deskPanel = new THREE.Mesh(new THREE.BoxGeometry(KW * 0.80, 0.16, 0.014), M.ebony);
  deskPanel.position.set(0, 0.09, 0);
  deskPanel.castShadow = true;
  const deskLip = new THREE.Mesh(new THREE.BoxGeometry(KW * 0.80, 0.016, 0.028), M.ebony);
  deskLip.position.set(0, 0.006, 0.016);
  desk.add(deskPanel, deskLip);
  // 中央支撑立柱
  const deskStrut = new THREE.Mesh(new THREE.CylinderGeometry(0.004, 0.005, 0.050, 10), M.brass);
  deskStrut.position.set(0, 0.015, 0.01);
  desk.add(deskStrut);
  desk.position.set(cx, 0.40, -0.10);
  desk.rotation.x = 0.28;
  root.add(desk);

  // ---------------------------------------------------------------
  // 8. 琴键（81 键，绕平衡销转动）
  // ---------------------------------------------------------------
  const keys = new Map();
  const keyMeshes = [];
  const pressArr = new Array(layout.keys.length).fill(0);
  const wSample = layout.keys.find((k) => !k.isBlack);
  const bSample = layout.keys.find((k) => k.isBlack);
  // 白键：圆角盒（边缘 2.5mm 倒角/软化），segments=2 → 5×5×5 细分
  const whiteGeo = new RoundedBoxGeometry(wSample.width, KEY_H, wSample.length, 2, 0.0025);
  // 黑键：含顶面倒角的拉伸（2mm chamfer）
  const blackGeo = buildChamferedBlackKey(bSample.width, BLACK_H, bSample.length);

  for (const k of layout.keys) {
    const isBlack = k.isBlack;
    const backZ = isBlack ? 0.002 : 0;
    const len = k.length;

    // pivot 放在平衡销位置（世界 (centerX, pivotY, pivotZ)）
    const pivotY = WHITE_TOP - KEY_H;          // 键底面高度 = 0.198
    const pivotZ = BALANCE_RAIL_Z;             // 0.049（所有键统一）
    const pivot = new THREE.Group();
    pivot.position.set(k.centerX, pivotY, pivotZ);

    // 键 mesh 在 pivot 局部坐标：中心在 (0, KEY_H/2, (backZ+frontZ)/2 - pivotZ)
    const meshLocalZ = backZ + len / 2 - pivotZ;
    const meshLocalY = KEY_H / 2;
    const topY = isBlack ? WHITE_TOP + BLACK_RISE : WHITE_TOP;
    // 为保持原接口 topY 不变（指向键面世界高度），记录 pivotY
    const mat = (isBlack ? M.blackKey : M.whiteKey).clone();
    mat.emissive = new THREE.Color(0x000000);

    const mesh = new THREE.Mesh(isBlack ? blackGeo : whiteGeo, mat);
    mesh.position.set(0, meshLocalY, meshLocalZ);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    mesh.userData.midi = k.midi;
    pivot.add(mesh);
    root.add(pivot);

    const frontDist = (backZ + len) - pivotZ;  // 键前缘到 pivot 的距离（杠杆长）
    const keyObj = {
      midi: k.midi, isBlack, pivot, mesh, material: mat,
      length: len, backZ, frontZ: backZ + len, centerX: k.centerX,
      topY, pivotY, pivotZ,
      press: 0, target: 0,
      maxAngle: Math.asin(KEY_DIP / Math.max(0.001, frontDist)),
    };
    keys.set(k.midi, keyObj);
    keyMeshes.push(mesh);
  }

  // ---------------------------------------------------------------
  // 9. 顶盖 + 铰链筒 + 支撑杆
  // ---------------------------------------------------------------
  const lidShape = buildBodyShape(x0 - 0.006, x1 + 0.006, DEPTH + 0.006);
  const lidGeo = extrudeUp(lidShape, 0.024, 96);
  const LID_HINGE_X = x0 + 0.020;
  const lidPivot = new THREE.Group();
  lidPivot.position.set(LID_HINGE_X, RIM_H + 0.012, 0);
  const lidMesh = new THREE.Mesh(lidGeo, M.ebony);
  lidMesh.position.x = -LID_HINGE_X;
  lidMesh.castShadow = true;
  lidMesh.receiveShadow = true;
  lidPivot.add(lidMesh);
  root.add(lidPivot);

  // 铰链筒：沿低音侧贯通。旧版长度取 DEPTH+0.04 且中心偏移算错，
  // 导致筒身朝琴身前沿外戳出 4cm（低音侧前端没有键盘遮挡，非常扎眼）。
  // 现改为两端各内收 2cm，完全落在琴身轮廓内。
  const hingeLen = DEPTH - 0.04;
  const hingeGeo = new THREE.CylinderGeometry(0.007, 0.007, hingeLen, 12);
  hingeGeo.rotateX(Math.PI / 2);
  const hinge = new THREE.Mesh(hingeGeo, M._hinge);
  hinge.position.set(LID_HINGE_X, RIM_H + 0.012, -(DEPTH - 0.02) / 2 - 0.01);
  root.add(hinge);
  // 铰链螺丝（4 颗，沿铰链分布）
  const hingeScrewGeo = new THREE.CylinderGeometry(0.0035, 0.0035, 0.006, 8);
  hingeScrewGeo.rotateX(Math.PI / 2);
  for (const hz of [0.10, 0.50, 0.90, 1.30]) {
    const hs = new THREE.Mesh(hingeScrewGeo, M._screw);
    hs.position.set(LID_HINGE_X + 0.005, RIM_H + 0.012, -hz);
    root.add(hs);
  }

  const propGeo = new THREE.CylinderGeometry(0.007, 0.007, 1, 10);
  const prop = new THREE.Mesh(propGeo, M.brass);
  prop.castShadow = true;
  root.add(prop);

  const LID_MAX = 0.69;   // ≈ 39.5°，使顶端不超过高度约束 1.8m
  let lidProgress = 1;
  const propBase = new THREE.Vector3(KW * 0.80, RIM_H + 0.002, -DEPTH * 0.30);
  const propLocal = new THREE.Vector3(KW * 0.80 - LID_HINGE_X, 0, -DEPTH * 0.30);

  function updateLid(p) {
    lidProgress = p;
    const angle = LID_MAX * p;
    lidPivot.rotation.z = angle;
    prop.visible = p > 0.05;
    if (prop.visible) {
      const top = propLocal.clone();
      top.applyAxisAngle(new THREE.Vector3(0, 0, 1), angle);
      top.add(lidPivot.position);
      orientCylinder(prop, propBase, top);
    }
  }
  updateLid(1);

  // ---------------------------------------------------------------
  // 10. 琴腿 / 脚轮 / 踏板架（直连键托 + 三连杆）/ 琴凳
  // ---------------------------------------------------------------
  const legH = -FLOOR_Y;
  const legPositions = [
    [x0 + 0.07, 0.02], [x1 - 0.07, 0.02], [KW * 0.30, -DEPTH * 0.86],
  ];
  for (const [lx, lz] of legPositions) {
    const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.034, 0.048, legH, 18), M.ebony);
    leg.position.set(lx, FLOOR_Y + legH / 2, lz);
    leg.castShadow = true;
    root.add(leg);
    const caster = new THREE.Mesh(new THREE.CylinderGeometry(0.026, 0.026, 0.020, 14), M.brass);
    caster.position.set(lx, FLOOR_Y + 0.010, lz);
    root.add(caster);
  }

  // 踏板琴架：两根侧立柱 + 横梁 + 踏板箱 + 三块踏板 + 三根连杆
  const lyreX = cx - 0.02, lyreZ = 0.10;
  const postTop = 0.178;                        // 直连键托底面（消除 22cm 悬空）
  const postBottom = FLOOR_Y + 0.020;
  const postH = postTop - postBottom;           // ≈ 0.66m
  const postThick = 0.022;
  for (const dx of [-0.075, 0.075]) {
    const post = new THREE.Mesh(new THREE.BoxGeometry(postThick, postH, postThick), M.ebony);
    post.position.set(lyreX + dx, (postTop + postBottom) / 2, lyreZ);
    post.castShadow = true;
    root.add(post);
  }
  // 横梁（踏板箱顶）
  const lyreBeam = new THREE.Mesh(new THREE.BoxGeometry(0.20, 0.012, 0.030), M.ebony);
  lyreBeam.position.set(lyreX, postBottom + 0.085, lyreZ);
  root.add(lyreBeam);
  // 踏板箱底座
  const lyreBase = new THREE.Mesh(new THREE.BoxGeometry(0.20, 0.024, 0.16), M.ebony);
  lyreBase.position.set(lyreX, postBottom + 0.012, lyreZ - 0.02);
  lyreBase.castShadow = true;
  root.add(lyreBase);

  // 三块踏板：每块绕后枢（前下后上抬）旋转
  const PEDAL_PIVOT_Z = lyreZ - 0.05;           // 踏板枢轴在踏板箱后部
  const pedalWidth = 0.028;
  const pedalDepth = 0.095;
  const pedalThick = 0.012;
  const pedalGroup = new THREE.Group();
  const pedals = [];
  [-0.040, 0, 0.040].forEach((dx, i) => {
    const pivot = new THREE.Group();
    pivot.position.set(lyreX + dx, postBottom + 0.062, PEDAL_PIVOT_Z);
    const p = new THREE.Mesh(new THREE.BoxGeometry(pedalWidth, pedalThick, pedalDepth), M.brass);
    p.position.set(0, 0, pedalDepth / 2);       // 把踏板 mesh 放在枢轴前方
    p.castShadow = true;
    pivot.add(p);
    pedalGroup.add(pivot);
    pedals.push({ pivot, mesh: p, baseAngle: 0, target: 0, press: 0 });
  });
  root.add(pedalGroup);

  // 三根连杆：踏板顶端 → 键托下方（薄壁圆筒实例化）
  const rodGeo = new THREE.CylinderGeometry(0.0035, 0.0035, 1, 6);
  const rods = new THREE.InstancedMesh(rodGeo, M.brass, 3);
  [-0.040, 0, 0.040].forEach((dx, i) => {
    const a = new THREE.Vector3(lyreX + dx, postBottom + 0.068, PEDAL_PIVOT_Z + pedalDepth * 0.85);
    const b = new THREE.Vector3(lyreX + dx, postTop - 0.020, lyreZ - 0.04);
    orientCylinderMatrix(rods, i, a, b);
  });
  rods.instanceMatrix.needsUpdate = true;
  root.add(rods);

  // 琴凳
  const bench = new THREE.Group();
  const seatY = 0.50;
  const seat = new THREE.Mesh(new THREE.BoxGeometry(0.58, 0.06, 0.35), M.leather);
  seat.position.y = seatY - 0.03;
  seat.castShadow = true; seat.receiveShadow = true;
  bench.add(seat);
  const benchLegLen = seatY - 0.06;
  for (const [sx, sz] of [[-0.24, -0.125], [0.24, -0.125], [-0.24, 0.125], [0.24, 0.125]]) {
    const lg = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.024, benchLegLen, 12), M.ebony);
    lg.position.set(sx, benchLegLen / 2, sz);
    lg.castShadow = true;
    bench.add(lg);
  }
  bench.position.set(cx, FLOOR_Y, 0.66);
  bench.name = 'bench';
  root.add(bench);

  // ---------------------------------------------------------------
  //  对外接口
  // ---------------------------------------------------------------
  const bounds = {
    centerX: cx, width: KW, depth: DEPTH,
    topY: RIM_H, keyTopY: WHITE_TOP, floorY: FLOOR_Y,
  };

  function setDamper(midi, lifted) {
    const i = damperIndex.get(midi);
    if (i === undefined) return;
    if (damperDefs[i].lifted === lifted) return;
    damperDefs[i].lifted = lifted;
    refreshDampers();
  }

  function setPedal(index, down) {
    if (pedals[index]) pedals[index].target = down ? 1 : 0;
  }

  function update(dt) {
    const kf = 1 - Math.exp(-dt * 34);
    let allRest = true;
    for (let i = 0; i < layout.keys.length; i++) {
      const k = keys.get(layout.keys[i].midi);
      const diff = k.target - k.press;
      if (Math.abs(diff) < 0.0005 && k.press === k.target) {
        pressArr[i] = k.press;
        continue;
      }
      allRest = false;
      k.press += diff * kf;
      // 绕平衡销旋转：前端下沉 10mm，后端微微抬起（被 fallboard 遮挡）
      // 符号约定：pivot 局部 +z 指向演奏者（前缘在 +z），绕 X 轴正向旋转时
      // y' = y·cosθ − z·sinθ，前缘 z>0 故 θ>0 使前缘下沉。此处必须取正号。
      k.pivot.rotation.x = k.press * k.maxAngle;
      pressArr[i] = k.press;
      const glow = k.press * (k.isBlack ? 0.5 : 0.34);
      k.material.emissive.setRGB(glow * 0.30, glow * 0.52, glow * 0.95);
    }
    if (!allRest) refreshHammers(pressArr);
    for (const p of pedals) {
      const diff = p.target - p.press;
      if (Math.abs(diff) > 0.001) {
        p.press += diff * (1 - Math.exp(-dt * 26));
        // 前端下踩：绕后枢 X 轴正向旋转
        p.pivot.rotation.x = p.press * 0.16;
      }
    }
  }

  return {
    group: root, keys, keyMeshes, bounds, layout, materials: M,
    setDamper, setPedal, updateLid, update,
    get lidProgress() { return lidProgress; },
  };
}

// ============================ 工具函数 ============================

/** 两段 BufferGeometry 合并（不依赖 BufferGeometryUtils） */
function mergeTwo(a, b) {
  const out = new THREE.BufferGeometry();
  const aPos = a.attributes.position.array;
  const bPos = b.attributes.position.array;
  const aIdx = a.index ? a.index.array : null;
  const bIdx = b.index ? b.index.array : null;
  const pos = new Float32Array(aPos.length + bPos.length);
  pos.set(aPos, 0);
  pos.set(bPos, aPos.length);
  out.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  if (aIdx || bIdx) {
    const aCount = aIdx ? aIdx.length : aPos.length / 3;
    const bCount = bIdx ? bIdx.length : bPos.length / 3;
    const idx = new Uint32Array(aCount + bCount);
    if (aIdx) idx.set(aIdx, 0);
    else for (let i = 0; i < aCount; i++) idx[i] = i;
    const offset = aPos.length / 3;
    if (bIdx) for (let i = 0; i < bCount; i++) idx[aCount + i] = bIdx[i] + offset;
    else for (let i = 0; i < bCount; i++) idx[aCount + i] = offset + i;
    out.setIndex(new THREE.BufferAttribute(idx, 1));
  }
  out.computeVertexNormals();
  return out;
}

/** 把圆柱放到两点之间（写入 InstancedMesh 的第 i 个实例） */
function orientCylinderMatrix(mesh, i, a, b) {
  const dir = new THREE.Vector3().subVectors(b, a);
  const len = dir.length();
  const pos = a.clone().addScaledVector(dir, 0.5);
  const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.clone().normalize());
  const m = new THREE.Matrix4().compose(pos, q, new THREE.Vector3(1, len, 1));
  mesh.setMatrixAt(i, m);
}

/**
 * 含顶面 2mm 倒角的梯形黑键：底部矩形 → 顶部略收窄 + 顶角倒角。
 * 由 2D 截面 ExtrudeGeometry + 后处理顶点缩放得到。
 */
function buildChamferedBlackKey(width, height, length) {
  const chamfer = 0.002;
  const topScale = 0.78;                       // 顶面宽度系数（与真琴接近）
  const s = new THREE.Shape();
  const halfW = width / 2;
  const xL = -halfW * topScale, xR = halfW * topScale;
  // 逆时针：底左 → 底右 → 右上 → 倒角 → 顶右 → 倒角 → 顶左 → 倒角 → 左上 → 倒角
  s.moveTo(-halfW, 0);
  s.lineTo(halfW, 0);
  s.lineTo(halfW, height - chamfer);
  s.lineTo(halfW - chamfer, height);
  s.lineTo(xR, height);
  s.lineTo(xL, height);
  s.lineTo(-halfW + chamfer, height);
  s.lineTo(-halfW, height - chamfer);
  s.closePath();
  const geo = new THREE.ExtrudeGeometry(s, {
    depth: length, bevelEnabled: false, curveSegments: 2, steps: 1,
  });
  // 几何坐标：x ∈ [-halfW, halfW], y ∈ [0, height], z ∈ [0, length]
  // 居中并翻转：让键底在 y=0，顶在 y=height，长度沿 z 居中
  geo.translate(0, 0, -length / 2);
  return geo;
}

/**
 * 外壳分缝：内框外缘的细暗色嵌条（让铸铁框/音板/外壳的接缝可读）。
 * 沿 innerPts 投放 1 段贴边的细盒。
 */
function addShellSeams(root, M, innerPts, depth) {
  // 内框顶面边缘的暗色细缝
  const seamGeo = new THREE.BufferGeometry();
  const positions = [];
  const n = innerPts.length;
  for (let i = 0; i < n; i++) {
    const p = innerPts[i], q = innerPts[(i + 1) % n];
    // 用两段形成 0.003m 宽的薄带：外侧 / 内侧
    const dx = q.x - p.x, dy = q.y - p.y;
    const l = Math.hypot(dx, dy) || 1;
    // 薄带：宽 0.003m，沿内框顶面 (0.35) 延伸
    const w = 0.003;
    // 法向外推
    const nx = -dy / l, ny = dx / l;
    const offX = nx * w, offY = ny * w;
    // 6 个顶点：p, q, q+off, p+off, p+off+down, q+off+down → 一个薄六面盒
    const yTop = 0.350, yBot = 0.348;
    const ax = p.x, ay = p.y, bx = q.x, by = q.y;
    // 简化：仅用顶部一条细线（薄盒）
    const a1x = ax, a1y = ay;
    const a2x = bx, a2y = by;
    const a3x = bx + offX, a3y = by + offY;
    const a4x = ax + offX, a4y = ay + offY;
    // 顶面
    positions.push(a1x, yTop, -a1y, a2x, yTop, -a2y, a3x, yTop, -a3y);
    positions.push(a1x, yTop, -a1y, a3x, yTop, -a3y, a4x, yTop, -a4y);
    // 底面
    positions.push(a1x, yBot, -a1y, a3x, yBot, -a3y, a2x, yBot, -a2y);
    positions.push(a1x, yBot, -a1y, a4x, yBot, -a4y, a3x, yBot, -a3y);
    // 外侧面
    positions.push(a1x, yTop, -a1y, a1x, yBot, -a1y, a2x, yBot, -a2y);
    positions.push(a1x, yTop, -a1y, a2x, yBot, -a2y, a2x, yTop, -a2y);
    // 内侧面
    positions.push(a4x, yTop, -a4y, a3x, yBot, -a3y, a1x, yBot, -a1y);
    positions.push(a4x, yTop, -a4y, a3x, yTop, -a3y, a3x, yBot, -a3y);
  }
  seamGeo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  seamGeo.computeVertexNormals();
  const seamMesh = new THREE.Mesh(seamGeo, M._seam);
  seamMesh.castShadow = false; seamMesh.receiveShadow = true;
  root.add(seamMesh);
}
